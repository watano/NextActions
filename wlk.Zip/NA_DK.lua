--0:name, 2:rank, 3:icon, 4:cost, 5:isFunnel, 6:powerType, 7:castTime, 8:minRange, 9:maxRange, 51:spell1/buff2/item3/marco4, 52:buff/debuff, 53:maxid

function getNA_DKSpells()
	return {
		['RaiseAlly']={['ids']={61999},['name']='Raise Ally',['buff']=0},
		['Vendetta']={['ids']={55136,50154,49015},['name']='Vendetta',['buff']=0},
		['Reaping']={['ids']={56835,56834,49208},['name']='Reaping',['buff']=0},
		['PlateMail']={['ids']={750},['name']='Plate Mail',['buff']=0},
		['Obliterate']={['ids']={66198,51425,51424,51423,49020},['name']='Obliterate',['buff']=0},--滅寂
		['ChainsOfIce']={['ids']={45524},['name']='Chains of Ice',['buff']=0},
		['Outbreak']={['ids']={55237,55236,49013},['name']='Outbreak',['buff']=0},
		['ScourgeStrike']={['ids']={55271,55270,55265,55090},['name']='Scourge Strike',['buff']=0},
		['ImprovedBloodPresence']={['ids']={50371,50365},['name']='Improved Blood Presence',['buff']=0},
		['Two-HandedWeaponSpecialization']={['ids']={55108,55107},['name']='Two-Handed Weapon Specialization',['buff']=0},
		['IcyTouch']={['ids']={49909,49904,49903,49896,45477},['name']='Icy Touch',['buff']=2},
		['Dirge']={['ids']={49599,49223},['name']='Dirge',['buff']=0},
		['Blood-CakedBlade']={['ids']={49628,49627,49219},['name']='Blood-Caked Blade',['buff']=0},
		['RavenousDead']={['ids']={49572,49571,48965},['name']='Ravenous Dead',['buff']=0},
		['NightOftheDead']={['ids']={55623,55620},['name']='Night of the Dead',['buff']=0},
		['MightOfMograine']={['ids']={49534,49533,49023},['name']='Might of Mograine',['buff']=0},
		['HowlingBlast']={['ids']={51411,51410,51409,49184},['name']='Howling Blast',['buff']=0},--凜風衝擊
		['ThreatOfThassarian']={['ids']={66192,66191,65661},['name']='Threat of Thassarian',['buff']=0},
		['BoneShield']={['ids']={49222},['name']='Bone Shield',['buff']=0},
		['RunicPowerMastery']={['ids']={50147,49455},['name']='Runic Power Mastery',['buff']=0},
		['TundraStalker']={['ids']={50130,50129,50128,50127,49202},['name']='Tundra Stalker',['buff']=0},
		['Toughness']={['ids']={49789,49788,49787,49786,49042},['name']='Toughness',['buff']=0},
		['RuneOftheFallenCrusader']={['ids']={53344},['name']='Rune of the Fallen Crusader',['buff']=0},
		['BloodyStrikes']={['ids']={49395,49394,48977},['name']='Bloody Strikes',['buff']=0},
		['Anti-MagicZone']={['ids']={51052},['name']='Anti-Magic Zone',['buff']=0},
		['DeathStrike']={['ids']={66188,49999,49998,49924,49923,45463},['name']='Death Strike',['buff']=0},
		['RuneOfCinderglacier']={['ids']={53341},['name']='Rune of Cinderglacier',['buff']=0},
		['DeathandDecay']={['ids']={49938,49937,49936,43265},['name']='Death and Decay',['buff']=0},
		['AbominationSMight']={['ids']={53138,53137},['name']='Abomination\'s Might',['buff']=0},
		['BloodGorged']={['ids']={61158,61157,61156,61155,61154},['name']='Blood Gorged',['buff']=0},
		['BloodPresence']={['ids']={48266},['name']='Blood Presence',['buff']=0},
		['Pestilence']={['ids']={50842},['name']='Pestilence',['buff']=0},
		['ScentOfBlood']={['ids']={49509,49508,49004},['name']='Scent of Blood',['buff']=0},
		['RaiseDead']={['ids']={46584},['name']='Raise Dead',['buff']=0},
		['CryptFever']={['ids']={49632,49631,49032},['name']='Crypt Fever',['buff']=0},
		['DarkConviction']={['ids']={49480,49479,49478,49477,48987},['name']='Dark Conviction',['buff']=0},
		['UnbreakableArmor']={['ids']={51271},['name']='Unbreakable Armor',['buff']=0},
		['BladeBarrier']={['ids']={55226,55225,49501,49500,49182},['name']='Blade Barrier',['buff']=0},
		['Sigil']={['ids']={52665},['name']='Sigil',['buff']=0},
		['MarkOfBlood']={['ids']={49005},['name']='Mark of Blood',['buff']=0},
		['Desecration']={['ids']={55667,55666},['name']='Desecration',['buff']=0},
		['SummonGargoyle']={['ids']={49206},['name']='Summon Gargoyle',['buff']=0},
		['WillOftheNecropolis']={['ids']={50150,50149,49189},['name']='Will of the Necropolis',['buff']=0},
		['Anticipation']={['ids']={55133,55132,55131,55130,55129},['name']='Anticipation',['buff']=0},
		['Impurity']={['ids']={49638,49636,49635,49633,49220},['name']='Impurity',['buff']=0},
		['One-HandedAxes']={['ids']={196},['name']='One-Handed Axes',['buff']=0},
		['RuneOfLichbane']={['ids']={53331},['name']='Rune of Lichbane',['buff']=0},
		['FrigidDreadplate']={['ids']={51109,51108,49186},['name']='Frigid Dreadplate',['buff']=0},
		['SuddenDoom']={['ids']={49530,49529,49018},['name']='Sudden Doom',['buff']=0},
		['ImprovedRuneTap']={['ids']={49489,49488,48985},['name']='Improved Rune Tap',['buff']=0},
		['Anti-MagicShell']={['ids']={48707},['name']='Anti-Magic Shell',['buff']=0},
		['MercilessCombat']={['ids']={49538,49024},['name']='Merciless Combat',['buff']=0},
		['ImprovedIcyTouch']={['ids']={51456,50031,49175},['name']='Improved Icy Touch',['buff']=0},
		['Cloth']={['ids']={9078},['name']='Cloth',['buff']=0},
		['DeathRuneMastery']={['ids']={50034,50033,49467},['name']='Death Rune Mastery',['buff']=0},
		['Mail']={['ids']={8737},['name']='Mail',['buff']=0},
		['RuneStrike']={['ids']={56815},['name']='Rune Strike',['buff']=0},
		['HungeringCold']={['ids']={49203},['name']='Hungering Cold',['buff']=0},
		['VeteranOftheThirdWar']={['ids']={50029,49526,49006},['name']='Veteran of the Third War',['buff']=0},
		['ImprovedUnholyPresence']={['ids']={50392,50391},['name']='Improved Unholy Presence',['buff']=0},
		['OnaPaleHorse']={['ids']={51267,49146},['name']='On a Pale Horse',['buff']=0},
		['Epidemic']={['ids']={49562,49036},['name']='Epidemic',['buff']=0},
		['Virulence']={['ids']={49568,49567,48962},['name']='Virulence',['buff']=0},
		['IcyTalons']={['ids']={50887,50886,50885,50884,50880},['name']='Icy Talons',['buff']=0},
		['VampiricBlood']={['ids']={55233},['name']='Vampiric Blood',['buff']=0},
		['ChillOftheGrave']={['ids']={50115,49149},['name']='Chill of the Grave',['buff']=0},
		['EmpowerRuneWeapon']={['ids']={47568},['name']='Empower Rune Weapon',['buff']=0},
		['Hysteria']={['ids']={49016},['name']='Hysteria',['buff']=0},
		['UnholyCommand']={['ids']={49589,49588},['name']='Unholy Command',['buff']=0},
		['DeathPact']={['ids']={48743},['name']='Death Pact',['buff']=0},
		['RuneTap']={['ids']={48982},['name']='Rune Tap',['buff']=0},
		['RageOfRivendare']={['ids']={50121,50120,50119,50118,50117},['name']='Rage of Rivendare',['buff']=0},
		['GhoulFrenzy']={['ids']={63560},['name']='Ghoul Frenzy',['buff']=0},
		['Two-HandedAxes']={['ids']={197},['name']='Two-Handed Axes',['buff']=0},
		['KillingMachine']={['ids']={51130,51129,51128,51127,51123},['name']='Killing Machine',['buff']=0},
		['NervesOfColdSteel']={['ids']={50138,50137,49226},['name']='Nerves of Cold Steel',['buff']=0},
		['BladedArmor']={['ids']={49393,49392,49391,49390,48978},['name']='Bladed Armor',['buff']=0},
		['UnholyPresence']={['ids']={48265},['name']='Unholy Presence',['buff']=0},
		['BloodTap']={['ids']={45529},['name']='Blood Tap',['buff']=0},
		['UnholyBlight']={['ids']={49194},['name']='Unholy Blight',['buff']=0},
		['Runeforging']={['ids']={53428},['name']='Runeforging',['buff']=0},
		['ArmyOftheDead']={['ids']={42650},['name']='Army of the Dead',['buff']=0},
		['Rime']={['ids']={59057,56822,49188},['name']='Rime',['buff']=0},
		['BloodBoil']={['ids']={49941,49940,49939,48721},['name']='Blood Boil',['buff']=0},
		['Chilblains']={['ids']={50043,50041,50040},['name']='Chilblains',['buff']=0},
		['DeathGate']={['ids']={50977},['name']='Death Gate',['buff']=0},
		['Strangulate']={['ids']={47476},['name']='Strangulate',['buff']=0},
		['Two-HandedSwords']={['ids']={202},['name']='Two-Handed Swords',['buff']=0},
		['BloodOftheNorth']={['ids']={54639,54638,54637},['name']='Blood of the North',['buff']=0},
		['Lichborne']={['ids']={49039},['name']='Lichborne',['buff']=0},
		['ViciousStrikes']={['ids']={51746,51745},['name']='Vicious Strikes',['buff']=0},
		['RuneOfSpellbreaking']={['ids']={54447},['name']='Rune of Spellbreaking',['buff']=0},
		['One-HandedSwords']={['ids']={201},['name']='One-Handed Swords',['buff']=0},
		['HeartStrike']={['ids']={55262,55261,55260,55259,55258,55050},['name']='Heart Strike',['buff']=0},
		['PathOfFrost']={['ids']={3714},['name']='Path of Frost',['buff']=0},
		['RuneOftheNerubianCarapace']={['ids']={70164},['name']='Rune of the Nerubian Carapace',['buff']=0},
		['Bloodworms']={['ids']={49543,49542,49027},['name']='Bloodworms',['buff']=0},
		['SpellDeflection']={['ids']={49497,49495,49145},['name']='Spell Deflection',['buff']=0},
		['Leather']={['ids']={9077},['name']='Leather',['buff']=0},
		['DancingRuneWeapon']={['ids']={49028},['name']='Dancing Rune Weapon',['buff']=0},
		['DarkCommand']={['ids']={56222},['name']='Dark Command',['buff']=0},
		['RuneOfRazorice']={['ids']={53343},['name']='Rune of Razorice',['buff']=0},
		['ForcefulDeflection']={['ids']={49410},['name']='Forceful Deflection',['buff']=0},
		['CorpseExplosion']={['ids']={51328,51327,51326,51325,49158},['name']='Corpse Explosion',['buff']=0},
		['GuileOfGorefiend']={['ids']={50191,50190,50187},['name']='Guile of Gorefiend',['buff']=0},
		['RuneOfSwordbreaking']={['ids']={54446},['name']='Rune of Swordbreaking',['buff']=0},
		['Butchery']={['ids']={49483,48979},['name']='Butchery',['buff']=0},
		['IceboundFortitude']={['ids']={48792},['name']='Icebound Fortitude',['buff']=0},
		['ImprovedFrostPresence']={['ids']={50385,50384},['name']='Improved Frost Presence',['buff']=0},
		['RuneOfSpellshattering']={['ids']={53342},['name']='Rune of Spellshattering',['buff']=0},
		['Deathchill']={['ids']={49796},['name']='Deathchill',['buff']=0},
		['One-HandedMaces']={['ids']={198},['name']='One-Handed Maces',['buff']=0},
		['BloodyVengeance']={['ids']={49504,49503,48988},['name']='Bloody Vengeance',['buff']=0},
		['Subversion']={['ids']={49491,49490,48997},['name']='Subversion',['buff']=0},
		['DeathGrip']={['ids']={49576},['name']='Death Grip',['buff']=0},
		['MagicSuppression']={['ids']={49611,49610,49224},['name']='Magic Suppression',['buff']=0},
		['IcyReach']={['ids']={55062,55061},['name']='Icy Reach',['buff']=0},
		['DeathCoil']={['ids']={49895,49894,49893,49892,47541},['name']='Death Coil',['buff']=0},
		['FrostStrike']={['ids']={55268,51419,51418,51417,51416,49143},['name']='Frost Strike',['buff']=0},--冰霜打擊
		['Desolation']={['ids']={66817,66816,66815,66814,66799},['name']='Desolation',['buff']=0},
		['ImprovedIcyTalons']={['ids']={55610},['name']='Improved Icy Talons',['buff']=0},
		['MasterOfGhouls']={['ids']={52143},['name']='Master of Ghouls',['buff']=0},
		['Annihilation']={['ids']={51473,51472,51468},['name']='Annihilation',['buff']=0},
		['Two-HandedMaces']={['ids']={199},['name']='Two-Handed Maces',['buff']=0},
		['FrostPresence']={['ids']={48263},['name']='Frost Presence',['buff']=0},
		['GlacierRot']={['ids']={49791,49790,49471},['name']='Glacier Rot',['buff']=0},
		['BlackIce']={['ids']={49664,49663,49662,49661,49140},['name']='Black Ice',['buff']=0},
		['Morbidity']={['ids']={49565,49564,48963},['name']='Morbidity',['buff']=0},
		['RuneOfSwordshattering']={['ids']={53323},['name']='Rune of Swordshattering',['buff']=0},
		['ImprovedDeathStrike']={['ids']={62908,62905},['name']='Improved Death Strike',['buff']=0},
		['EbonPlaguebringer']={['ids']={51161,51160,51099},['name']='Ebon Plaguebringer',['buff']=0},
		['WanderingPlague']={['ids']={49655,49654,49217},['name']='Wandering Plague',['buff']=0},
		['Polearms']={['ids']={200},['name']='Polearms',['buff']=0},
		['Necrosis']={['ids']={51465,51464,51463,51462,51459},['name']='Necrosis',['buff']=0},
		['MindFreeze']={['ids']={47528},['name']='Mind Freeze',['buff']=0},
		['RuneOftheStoneskinGargoyle']={['ids']={62158},['name']='Rune of the Stoneskin Gargoyle',['buff']=0},
		['Acclimation']={['ids']={50152,50151,49200},['name']='Acclimation',['buff']=0},
		['EndlessWinter']={['ids']={49657,49137},['name']='Endless Winter',['buff']=0},
		['BloodStrike']={['ids']={49930,49929,49928,49927,49926,45902},['name']='Blood Strike',['buff']=0},
		['PlagueStrike']={['ids']={49921,49920,49919,49918,49917,45462},['name']='Plague Strike',['buff']=0},
		['KillingMachine']={['ids']={51124},['name']='Killing Machine',['buff']=1},
		['HornOfWinter']={['ids']={57623,57330},['name']='Horn of Winter',['buff']=1},
		['FreezingCloud']={['ids']={47579},['name']='Freezing Cloud',['buff']=1},
		['FrostFever']={['ids']={59921,71129,69917,67934,67933,67932,67878,67767,67719},['name']='Frost Fever',['buff']=2},
		['BloodPlague']={['ids']={59879,71923,71119,69911,61601,61111,59984,58844,58840,57601},['name']='Blood Plague',['buff']=2}
	};
end

function getNA_DKActions(no)
	local actions = {'IcyTouch','PlagueStrike','DeathStrike','BloodStrike','RuneStrike','Obliterate','DeathCoil','DeathGrip','HornOfWinter','BloodBoil','Pestilence','IceboundFortitude','VampiricBlood'};
	if(no == 1)then
--		return NA_ArrayAppend(actions,{'HowlingBlast','FrostStrike','BloodTap','UnbreakableArmor'});
		return NA_ArrayAppend(actions,{'ScourgeStrike','BoneShield','SummonGargoyle'});
	elseif(no ==0)then
		return NA_ArrayAppend(actions,{'DarkCommand','RuneTap','HeartStrike','DancingRuneWeapon'});
	elseif(no ==2)then
		return NA_ArrayAppend(actions,{'EmpowerRuneWeapon','Hysteria','DancingRuneWeapon','HeartStrike'});
	end
	return {};
end

function NA_DKDps()
	if(W_IsInCombat())then
		-- 保命施法
		if(false 
			or NA_Fire(W_HPlevel("player") < 0.2 or NA_IsProtection, 'VampiricBlood', "player")
			or NA_Fire(W_HPlevel("player") < 0.5 or NA_IsProtection, 'RuneTap', "player")
			or NA_Fire(W_HPlevel("player") < 0.45 or NA_IsProtection, 'IceboundFortitude', "player")
			or NA_Fire(W_HPlevel("player") < 0.8 or NA_IsProtection, 'BoneShield', "player")
		)then 
			return true;
		end

		if(W_TargetCanAttack()) then
			-- 保命施法
			if(false 
				or NA_Fire(W_HPlevel("player") < 0.5 or NA_IsProtection, 'DeathStrike', "target")
			)then return true; end
			-- attack
			local FrostFeverAndBloodPlague = (NA_IsAOE and W_BuffCount('FrostFever','target', true) > 0 and W_BuffCount('BloodPlague','target', true) > 0);
			if(NA_ProfileNo == 0)then
				if(false
					or (NA_Fire(FrostFeverAndBloodPlague, 'BloodBoil', "target", 1000))
					or (NA_Fire(FrostFeverAndBloodPlague, 'Pestilence', "target",1000))
					or NA_Fire(not NA_IsMaxDps and not W_isTanking(), 'DarkCommand', "target")
					or NA_Fire(not NA_IsMaxDps and not W_isTanking(), 'DeathGrip', "target")
					or NA_Cast4NoBuffs({'FrostFever'}, 'IcyTouch', "target")
					or NA_Cast4NoBuffs({'BloodPlague'}, 'PlagueStrike', "target")
					or NA_Fire(true, 'RuneStrike', "target")
					or NA_Fire(W_PowerLevel('player') >= 0.6, 'DeathCoil', "target")
					or NA_Fire(true, 'DeathStrike', "target")
					or NA_Fire(true, 'BloodStrike', "target")
				)then return true; end
			elseif(NA_ProfileNo == 1)then
				if(false
--			--双持冰
--					or NA_Fire(W_BuffCount('KillingMachine','player', true) > 0 or W_PowerLevel('player') >= 1, 'FrostStrike', "target")
--					or NA_Fire(W_BuffCount('FreezingCloud','player', true) > 0, 'HowlingBlast', "target")
--					or NA_Fire(NA_IsMaxDps, 'BloodTap', "target")
--					or NA_Fire(NA_IsMaxDps, 'UnbreakableArmor', "target")
--					or NA_Fire(W_BuffCount('FrostFever','target', false) <= 0, 'HowlingBlast', "target")
--					-- or NA_Fire(W_BuffCount('BloodPlague','target', false) <= 0, 'PlagueStrike', "target")
--					or NA_Fire(true, 'Obliterate', "target")
--					or NA_Fire(true, 'HowlingBlast', "target")
--					or NA_Fire(true, 'BloodStrike', "target")
--					or NA_Cast4NoBuffs({'HornOfWinter'}, 'HornOfWinter', "player")
--					or NA_Fire(true, 'RuneStrike', "target")
--			--[主邪副冰]不出秽聚 0/17/54
--有秽聚：瘟疫打击>冰触>血打>血打>天灾ScourgeStrike>死亡缠绕>号角>天灾>缠绕>天灾>天灾>缠绕>(缠绕)
--无秽聚：瘟疫>冰触>血打>天灾>血打>缠绕>号角>天灾>血打>天灾>血打>缠绕>缠绕>(缠绕)
--AOE循环 初始：冰触>瘟疫>传染>凋零>缠绕>号角 天灾>血打>血沸>天灾>缠绕>缠绕>天灾>传染>凋零>缠绕>号角 
					or (NA_Fire(FrostFeverAndBloodPlague, 'BloodBoil', "target", 10000))
					or (NA_Fire(FrostFeverAndBloodPlague, 'Pestilence', "target", 10000))
					or NA_Cast4NoBuffs({'BloodPlague'}, 'PlagueStrike', "target")
					or NA_Cast4NoBuffs({'FrostFever'}, 'IcyTouch', "target")
					or NA_Fire(not NA_IsAOE, 'BloodStrike', "target")
					or NA_Fire(true, 'ScourgeStrike', "target")
					or NA_Fire(W_PowerLevel('player') >= 0.6, 'DeathCoil', "target")
					or (not NA_IsMaxDps and NA_Cast4NoBuffs({'HornOfWinter'}, 'HornOfWinter', "player"))
					or NA_Fire(NA_IsMaxDps, 'SummonGargoyle', "target")
				)then return true; end
			elseif(NA_ProfileNo == 2)then
				if(false
					--力量碎心
					or NA_Fire(NA_IsMaxDps, 'EmpowerRuneWeapon', "target")
					or NA_Cast4NoBuffs({'BloodPlague'}, 'PlagueStrike', "target")
					or NA_Cast4NoBuffs({'FrostFever'}, 'IcyTouch', "target")
					or NA_Fire(NA_IsMaxDps, 'Hysteria', "target")
					or NA_Fire(true, 'DancingRuneWeapon', "target")
					or NA_Fire(true, 'HeartStrike', "target")
					or NA_Fire(true, 'DeathStrike', "target")
					or NA_Cast4NoBuffs({'HornOfWinter'}, 'HornOfWinter', "player")
				)then return true; end
			end
		elseif(UnitCanAssist("player", "target") and UnitIsPlayer("target"))then
			if(NA_ProfileNo == 0)then

			end
			return false;
		end
	else
		if(false 
			or NA_Cast4NoBuffs({'HornOfWinter'}, 'HornOfWinter', "player")
			or NA_Cast4NoBuffs({'BoneShield'}, 'BoneShield', "player")
		)then return true; end
		--start attack
		if(not W_TargetIsBoss() and W_TargetCanAttack())then 
			if(NA_Fire(true, 'IcyTouch', "target") or NA_Fire(true, 'DeathGrip', "target"))then return true; end
		end
	end
	return false;
end