--0:name, 2:rank, 3:icon, 4:cost, 5:isFunnel, 6:powerType, 7:castTime, 8:minRange, 9:maxRange, 51:spell1/buff2/item3/marco4, 52:buff/debuff, 53:maxid

function getNA_DruidSpells()
	return {
		['DireBearForm']={['ids']={9634},['name']='Dire Bear Form',['buff']=1},
		['TravelForm']={['ids']={783},['name']='Travel Form',['buff']=1},
		['CatForm']={['ids']={768},['name']='Cat Form',['buff']=0},
		['Cyclone']={['ids']={33786},['name']='Cyclone',['buff']=0},
		['Dash']={['ids']={33357,9821,1850},['name']='Dash',['buff']=0},
		['Rip']={['ids']={49800,49799,27008,9896,9894,9752,9493,9492,1079},['name']='Rip',['buff']=0},
		['Maul']={['ids']={48480,48479,26996,9881,9880,9745,8972,6809,6808,6807},['name']='Maul',['buff']=0},
		['Hibernate']={['ids']={18658,18657,2637},['name']='Hibernate',['buff']=0},
		['FeralCharge-Bear']={['ids']={16979},['name']='Feral Charge - Bear',['buff']=0},
		['Prowl']={['ids']={5215},['name']='Prowl',['buff']=1},
		['Claw']={['ids']={48570,48569,27000,9850,9849,5201,3029,1082},['name']='Claw',['buff']=0},
		['Starfire']={['ids']={48465,48464,26986,25298,9876,9875,8951,8950,8949,2912},['name']='Starfire',['buff']=1},
		['FrenziedRegeneration']={['ids']={22842},['name']='Frenzied Regeneration',['buff']=1},
		['Swipe_Bear']={['ids']={48562,48561,26997,9908,9754,780,779,769},['name']='Swipe (Bear)',['buff']=0},
		['Thorns']={['ids']={53307,26992,9910,9756,8914,1075,782,467},['name']='Thorns',['buff']=1},
		['SootheAnimal']={['ids']={26995,9901,8955,2908},['name']='Soothe Animal',['buff']=0},
		['GiftOftheWild']={['ids']={48470,26991,21850,21849},['name']='Gift of the Wild',['buff']=1},
		['MarkOftheWild']={['ids']={48469,26990,9885,9884,8907,6756,5234,5232,1126},['name']='Mark of the Wild',['buff']=1},
		['Innervate']={['ids']={29166},['name']='Innervate',['buff']=1},
		['AquaticForm']={['ids']={1066},['name']='Aquatic Form',['buff']=0},
		['RemoveCurse']={['ids']={2782},['name']='Remove Curse',['buff']=0},
		['CurePoison']={['ids']={8946},['name']='Cure Poison',['buff']=0},
		['Bash']={['ids']={8983,6798,5211},['name']='Bash',['buff']=0},
		['SwiftFlightForm']={['ids']={40120},['name']='Swift Flight Form',['buff']=0},
		['Lifebloom']={['ids']={48451,48450,33763},['name']='Lifebloom',['buff']=1},
		['FeralCharge-Cat']={['ids']={49376},['name']='Feral Charge - Cat',['buff']=1},
		['Tranquility']={['ids']={48447,48446,44208,44207,44206,44205,44203,26983,9863,9862,8918,740},['name']='Tranquility',['buff']=0},
		['InsectSwarm']={['ids']={48468,27013,24977,24976,24975,24974},['name']='Insect Swarm',['buff']=2},
		['Cower']={['ids']={48575,31709,27004,9892,9000,8998},['name']='Cower',['buff']=0},
		['Lacerate']={['ids']={48568,48567,33745},['name']='Lacerate',['buff']=2},
		['Ravage']={['ids']={48579,48578,27005,9867,9866,6787,6785},['name']='Ravage',['buff']=0},
		['TigerSFury']={['ids']={50213,50212,9846,9845,6793,5217},['name']='Tiger\'s Fury',['buff']=1},
		['EntanglingRoots']={['ids']={53308,26989,9853,9852,5196,5195,1062,339},['name']='Entangling Roots',['buff']=0},
		['Teleport:Moonglade']={['ids']={18960},['name']='Teleport: Moonglade',['buff']=0},
		['HealingTouch']={['ids']={48378,48377,26979,26978,25297,9889,9888,9758,8903,6778,5189,5188,5187,5186,5185},['name']='Healing Touch',['buff']=0},
		['Barkskin']={['ids']={22812},['name']='Barkskin',['buff']=1},
		['Enrage']={['ids']={5229},['name']='Enrage',['buff']=1},
		['Revive']={['ids']={50769,50768,50767,50766,50765,50764,50763},['name']='Revive',['buff']=0},
		['SavageDefense']={['ids']={62600},['name']='Savage Defense',['buff']=0},
		['MoonkinForm']={['ids']={24858},['name']='Moonkin Form',['buff']=0},
		['Rake']={['ids']={48574,48573,27003,9904,1824,1823,1822},['name']='Rake',['buff']=2},
		['Swipe_Cat']={['ids']={62078},['name']='Swipe (Cat)',['buff']=0},
		['Regrowth']={['ids']={48443,48442,26980,9858,9857,9856,9750,8941,8940,8939,8938,8936},['name']='Regrowth',['buff']=1},
		['Nourish']={['ids']={50464},['name']='Nourish',['buff']=0},
		['Typhoon']={['ids']={61384,53226,53225,53223},['name']='Typhoon',['buff']=0},
		['FlightForm']={['ids']={33943},['name']='Flight Form',['buff']=0},
		['Rebirth']={['ids']={48477,26994,20748,20747,20742,20739,20484},['name']='Rebirth',['buff']=0},
		['TrackHumanoids']={['ids']={5225},['name']='Track Humanoids',['buff']=0},
		['SavageRoar']={['ids']={52610},['name']='Savage Roar',['buff']=1},
		['Growl']={['ids']={6795},['name']='Growl',['buff']=0},
		['AbolishPoison']={['ids']={2893},['name']='Abolish Poison',['buff']=0},
		['Mangle_Bear']={['ids']={48564,48563,33987,33986,33878},['name']='Mangle (Bear)',['buff']=2},
		['FaerieFire_Feral']={['ids']={16857},['name']='Faerie Fire (Feral)',['buff']=2},
		['Mangle_Cat']={['ids']={48566,48565,33983,33982,33876},['name']='Mangle (Cat)',['buff']=2},
		['Hurricane']={['ids']={48467,27012,17402,17401,16914},['name']='Hurricane',['buff']=0},
		['DemoralizingRoar']={['ids']={48560,48559,26998,9898,9747,9490,1735,99},['name']='Demoralizing Roar',['buff']=2},
		['TreeOfLife']={['ids']={33891,5420},['name']='Tree of Life',['buff']=1},
		['NatureSGrasp']={['ids']={53312,27009,17329,16813,16812,16811,16810,16689},['name']='Nature\'s Grasp',['buff']=1},
		['Shred']={['ids']={48572,48571,27002,27001,9830,9829,8992,6800,5221},['name']='Shred',['buff']=0},
		['WildGrowth']={['ids']={53251,53249,53248},['name']='Wild Growth',['buff']=1},
		['Wrath']={['ids']={48461,48459,26985,26984,9912,8905,6780,5180,5179,5178,5177,5176},['name']='Wrath',['buff']=1},
		['BearForm']={['ids']={5487},['name']='Bear Form',['buff']=0},
		['Pounce']={['ids']={49803,27006,9827,9823,9005},['name']='Pounce',['buff']=0},
		['ChallengingRoar']={['ids']={5209},['name']='Challenging Roar',['buff']=0},
		['Starfall']={['ids']={53201,53200,53199},['name']='Starfall',['buff']=0},
		['FaerieFire']={['ids']={770},['name']='Faerie Fire',['buff']=2},
		['FerociousBite']={['ids']={48577,48576,31018,24248,22829,22828,22827,22568},['name']='Ferocious Bite',['buff']=0},
		['Moonfire']={['ids']={48463,48462,26988,26987,9835,9834,9833,8929,8928,8927,8926,8925,8924,8921},['name']='Moonfire',['buff']=2},
		['FelineGrace']={['ids']={20719},['name']='Feline Grace',['buff']=0},
		['Rejuvenation']={['ids']={48441,48440,26982,26981,25299,9841,9840,9839,8910,3627,2091,2090,1430,1058,774},['name']='Rejuvenation',['buff']=1},
		['Maim']={['ids']={49802,22570},['name']='Maim',['buff']=0},
		['Swiftmend']={['ids']={18562},['name']='Swiftmend',['buff']=0},
		['Berserk']={['ids']={50334},['name']='Berserk',['buff']=1},
		['Eclipse_Lunar']={['ids']={48518},['name']='Eclipse (Lunar)',['buff']=1},
		['Eclipse_Solar']={['ids']={48517},['name']='Eclipse (Solar)',['buff']=1}
	};
end

function getNA_DruidActions(no)
	local actions = {'Barkskin','HealingTouch','MarkOftheWild','Thorns'};
	if(no == 1 or no ==2)then
		return NA_ArrayAppend(actions,{'AbolishPoison','RemoveCurse','FaerieFire','Wrath','Starfire','Moonfire','NatureSGrasp','Innervate','InsectSwarm','Regrowth','Rejuvenation','Lifebloom','WildGrowth','Nourish','Swiftmend'}); --平衡
	elseif(no ==0)then
		return NA_ArrayAppend(actions,{'FaerieFire_Feral','Berserk',
		'Claw','Rake','TigerSFury','FerociousBite','Mangle_Cat','FeralCharge-Cat','Swipe_Cat','SavageRoar','Shred','Rip',--貓
		'Growl','ChallengingRoar','Swipe_Bear','Lacerate','Mangle_Bear','FrenziedRegeneration','Maul','DemoralizingRoar','FeralCharge-Bear'--熊
		}); --野性貓
	end
	return {};
end

function NA_DruidDps()
	if(W_IsInCombat())then
		-- 保命施法
		if(false 
			or NA_Fire(W_HPlevel("player") < 0.8, 'Barkskin', "player") 
			or NA_Fire(NA_ProfileNo == 0 and W_HPlevel("player") < 0.5, 'FrenziedRegeneration', "player")
		)then 
			return true;
		end

		if(W_TargetCanAttack()) then
			-- attack
			if(NA_ProfileNo == 0)then
				if(GetShapeshiftForm() == 1)then
					if(false
						or NA_Fire(NA_IsProtection, 'HealingTouch', "player")
						or NA_Fire(not NA_IsMaxDps and W_isTanking(), 'Growl', "target")
						or NA_Fire(not NA_IsMaxDps and W_isTanking(), 'FaerieFire_Feral', "target")
						or NA_Fire(not NA_IsMaxDps and W_isTanking(), 'ChallengingRoar', "target")
						or (NA_IsAOE and NA_Cast4NoBuffs({'DemoralizingRoar'}, 'DemoralizingRoar', "target"))
						or NA_Fire(NA_IsAOE, 'Swipe_Bear', "target")
						or NA_KeepBuff('Lacerate', "target", true, 5)
--						or NA_Fire(W_BuffCount('Lacerate', "target", true) < 5, 'Lacerate', "target")
						or NA_Fire(true, 'Mangle_Bear', "target")
						or NA_Fire(not NA_IsAOE and W_PowerLevel("player") >= 0.5, 'Maul', "target")
					)then 
						return true;
					end
				elseif(GetShapeshiftForm() == 3)then
				--1. 保持野蛮咆哮 
				--2. 保持割碎(芒果) 
				--3. 保持扫击 
				--4. 用撕碎攒星(2条和3条更重要) 
				--5. 如果有5星，没有撕扯，上撕扯 
				--6. 如果低于30能量，使用猛虎之怒 
				--7. 清晰预兆的时候请使用撕碎 
					if(NA_Cast4NoBuffs({'FaerieFire_Feral'}, 'FaerieFire_Feral', "target")
						or NA_Fire(NA_IsMaxDps and W_BuffCount('TigerSFury', "player", true) > 0 and W_PowerLevel("player") > 0.7 , 'Berserk', "target")
						or NA_Fire(W_BuffCount('SavageRoar', "player", true) <= 0 and GetComboPoints("player","target") > 2, 'SavageRoar', "target")
						or NA_Fire(NA_IsAOE, 'Swipe_Cat', "target")
						or NA_Cast4NoBuffs({'Mangle_Cat'}, 'Mangle_Cat', "target")
						or NA_Cast4NoBuffs({'Rake'}, 'Rake', "target")
						or NA_Fire(NA_IsMaxDps and GetComboPoints("player","target") < 5, 'Shred', "target")
						or NA_Fire(not NA_IsMaxDps and GetComboPoints("player","target") < 5, 'Claw', "target")
						or NA_Fire(GetComboPoints("player","target") > 4, 'Rip', "target")
						or NA_Fire(W_PowerLevel("player") < 0.3, 'TigerSFury', "player")
					)then 
						return true;
					end
				end
			elseif(NA_ProfileNo == 2)then
				if((UnitInRaid('player')~=nil and 
					(false
					or	NA_Cast4NoBuffs({'FaerieFire'}, 'FaerieFire', "target")
					or NA_Fire(W_BuffCount('Eclipse_Solar', "player", true) > 0, 'Wrath', "target") --月蚀1-> 愤怒
					or NA_Fire(W_BuffCount('Eclipse_Lunar', "player", true) > 0, 'Starfire', "target") --月蚀2-> 星火术
					)) or (false
					or NA_Fire(W_HP("target") < 1000, 'Moonfire', "target")
					or NA_Cast4NoBuffs({'InsectSwarm'}, 'InsectSwarm', "target")
					or NA_Cast4NoBuffs({'Moonfire'}, 'Moonfire', "target")
					or NA_Fire(true, 'Wrath', "target")
					)
				)then
					return true;
				end
			end
		elseif(UnitCanAssist("player", "target") and UnitIsPlayer("target"))then
			if(NA_ProfileNo == 1)then
				if(UnitName("target") == UnitName("player") and NA_Fire(W_PowerLevel("player") < 0.6, 'Innervate', "player"))then 
					return true; 
				end
				if(false 
					or NA_Fire(W_HPlevel("target") < 0.5, 'Swiftmend','target')
					or NA_Fire(not NA_IsMaxDps and W_checkDeBuffs("target", "Poison"), 'AbolishPoison', "target")
					or NA_Fire(not NA_IsMaxDps and W_checkDeBuffs("target", "Curse"), 'RemoveCurse', "target")
					or NA_Cast4NoBuffs({'WildGrowth'}, 'WildGrowth', "target")
					or NA_Cast4NoBuffs({'Rejuvenation'}, 'Rejuvenation', "target")
					or NA_Cast4NoBuffs({'Lifebloom'}, 'Lifebloom', "target")
					or NA_Fire(W_HPlevel("target") < 0.7, 'Nourish', "target")
					or NA_Fire(W_HPlevel("target") < 0.8 and W_BuffCount('Lifebloom', "target", true)<3, 'Lifebloom', "target")
				)then 
					return true;
				end
			end
			return false;
		end
	else
		if(UnitCanAssist("player", "target") and UnitIsPlayer("target")
			and (NA_Cast4NoBuffs({'MarkOftheWild','GiftOftheWild'}, 'MarkOftheWild', "target", true) 
				or NA_Cast4NoBuffs({'Thorns'}, 'Thorns', "target", true))) then 
			return true;
		end

		if(UnitName("target") == UnitName("player") and NA_Fire(W_HPlevel("target") < 0.95, 'HealingTouch', "target")) then --治疗之触
			return true;
		end

		--start attack
		if(W_TargetCanAttack())then 
			if(GetShapeshiftForm() == 1 or GetShapeshiftForm() == 3)then
				if(NA_Cast4NoBuffs({'FaerieFire_Feral'}, 'FaerieFire_Feral', "target") 
					or (GetShapeshiftForm() == 1 and NA_Fire(true, 'FeralCharge-Bear', "target"))
					or (GetShapeshiftForm() == 3 and NA_Fire(true, 'FeralCharge-Cat', "target"))
				)then 
					return true; 
				end
				if(GetShapeshiftForm() == 3 and W_checkBuffs({'Prowl'}, "player", true))then
					-- if(NA_Fire(true, 'Pounce', "target"))then return true; end
				end
			else
				if(NA_Fire(true, 'Wrath', "target"))then return true; end
			end
		end
	end
	return false;
end